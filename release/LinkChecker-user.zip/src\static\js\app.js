const scanForm = document.getElementById("scan-form");
const pageUrlInput = document.getElementById("page-url");
const pageUrl2Input = document.getElementById("page-url-2");
const scanButton = document.getElementById("scan-button");
const includeExternalInput = document.getElementById("include-external");
const includeAssetsInput = document.getElementById("include-assets");
const scanTimeoutInput = document.getElementById("scan-timeout");
const scanWorkersInput = document.getElementById("scan-workers");
const formError = document.getElementById("form-error");
const appStatus = document.getElementById("app-status");
const appStatusText = document.getElementById("app-status-text");
const historyList = document.getElementById("history-list");
const historyPanel = document.getElementById("history-panel");
const historySubtitle = document.getElementById("history-subtitle");
const refreshHistoryButton = document.getElementById("refresh-history-button");
const clearHistoryButton = document.getElementById("clear-history-button");
const toggleHistoryButton = document.getElementById("toggle-history-button");

const emptySection = document.getElementById("empty-section");
const loadingSection = document.getElementById("loading-section");
const loadingUrlElement = document.getElementById("loading-url");
const loadingStepElement = document.getElementById("loading-step");
const loadingStepsElement = document.getElementById("loading-steps");
const resultsSection = document.getElementById("results-section");
const scanTabs = document.getElementById("scan-tabs");

const totalLinksElement = document.getElementById("total-links");
const goodLinksElement = document.getElementById("good-links");
const redirectedLinksElement = document.getElementById("redirected-links");
const brokenLinksElement = document.getElementById("broken-links");
const errorLinksElement = document.getElementById("error-links");
const healthScoreElement = document.getElementById("health-score");
const healthMessageElement = document.getElementById("health-message");
const scanSummaryMessageElement = document.getElementById("scan-summary-message");
const distributionBar = document.getElementById("distribution-bar");
const needsActionFilterButton = document.getElementById("needs-action-filter");
const issuesSubtitleElement = document.getElementById("issues-subtitle");
const issuesList = document.getElementById("issues-list");
const toggleIssuesButton = document.getElementById("toggle-issues-button");

const sourcePageElement = document.getElementById("source-page");
const resultsTableBody = document.getElementById("results-table-body");
const resultsSearchInput = document.getElementById("results-search");
const statusFilter = document.getElementById("status-filter");
const exportCsvButton = document.getElementById("export-csv-button");

let currentResults = [];
let currentSourcePage = "";
let selectedHistoryScanId = "";
let currentSort = {
    key: null,
    direction: "asc",
};
let quickFilter = "all";
let loadingTimer = null;
let loadingStepIndex = 0;
let batchScans = [];
let activeBatchScanIndex = 0;

const loadingSteps = [
    "Rendering page",
    "Extracting links",
    "Checking links",
    "Building report",
];


function formatHistoryDate(value) {
    if (!value) {
        return "Unknown date";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "Unknown date";
    }

    return date.toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
    });
}


/**
 * Update the compact status indicator in the app header.
 */
function setAppStatus(status, label) {
    appStatus.dataset.status = status;
    appStatusText.textContent = label;
}


function clampNumber(value, fallback, min, max) {
    const parsedValue = Number(value);

    if (!Number.isFinite(parsedValue)) {
        return fallback;
    }

    return Math.min(Math.max(Math.round(parsedValue), min), max);
}


function getScanOptions() {
    return {
        include_external: includeExternalInput.checked,
        include_assets: includeAssetsInput.checked,
        timeout: clampNumber(scanTimeoutInput.value, 20, 1, 60),
        max_workers: clampNumber(scanWorkersInput.value, 12, 1, 32),
    };
}


function setScanControlsDisabled(isDisabled) {
    scanButton.disabled = isDisabled;
    pageUrlInput.disabled = isDisabled;
    pageUrl2Input.disabled = isDisabled;
    includeExternalInput.disabled = isDisabled;
    includeAssetsInput.disabled = isDisabled;
    scanTimeoutInput.disabled = isDisabled;
    scanWorkersInput.disabled = isDisabled;
}


function updateLoadingStep(index) {
    loadingStepIndex = Math.min(index, loadingSteps.length - 1);
    loadingStepElement.textContent = loadingSteps[loadingStepIndex];

    loadingStepsElement.querySelectorAll("li").forEach((item) => {
        const itemIndex = Number(item.dataset.step);

        item.dataset.state = itemIndex < loadingStepIndex
            ? "done"
            : itemIndex === loadingStepIndex
                ? "active"
                : "pending";
    });
}


function startLoadingState(pageUrl, label = "Scanning") {
    emptySection.classList.add("hidden");
    resultsSection.classList.add("hidden");
    loadingSection.classList.remove("hidden");
    loadingUrlElement.textContent = pageUrl;
    updateLoadingStep(0);
    setAppStatus("scanning", label);

    window.clearInterval(loadingTimer);

    loadingTimer = window.setInterval(() => {
        updateLoadingStep(loadingStepIndex + 1);
    }, 1800);
}


function stopLoadingState() {
    window.clearInterval(loadingTimer);
    loadingTimer = null;
    loadingSection.classList.add("hidden");
}


function updateLiveScanProgress(job) {
    window.clearInterval(loadingTimer);
    loadingTimer = null;

    const stageLabels = {
        queued: "Queued",
        starting: "Starting scan",
        rendering: "Rendering page",
        extracting: "Extracting links",
        checking: "Checking links",
        building: "Building report",
        completed: "Scan completed",
        failed: "Scan failed",
    };
    const stepIndexes = {
        rendering: 0,
        extracting: 1,
        checking: 2,
        building: 3,
        completed: 3,
    };
    const label = stageLabels[job.stage] || "Scanning";
    const progress = job.total_links > 0
        ? ` (${job.checked_links} of ${job.total_links} links)`
        : "";

    loadingStepElement.textContent = `${label}${progress}`;
    loadingUrlElement.textContent = job.active_url || "Preparing scan";

    if (stepIndexes[job.stage] !== undefined) {
        updateLoadingStep(stepIndexes[job.stage]);
        loadingStepElement.textContent = `${label}${progress}`;
    }
}


/**
 * Fallback for older scan history entries without status_group.
 */
function normalizeStatus(status) {
    if (!status) {
        return "unknown";
    }

    const normalizedStatus = status
        .toString()
        .trim()
        .toLowerCase();

    if (
        normalizedStatus === "good" ||
        normalizedStatus === "ok" ||
        normalizedStatus === "valid" ||
        normalizedStatus === "interactive element"
    ) {
        return "good";
    }

    if (
        normalizedStatus === "redirected" ||
        normalizedStatus === "redirect"
    ) {
        return "redirected";
    }

    if (
        normalizedStatus === "broken" ||
        normalizedStatus === "failed" ||
        normalizedStatus === "unauthorized" ||
        normalizedStatus === "forbidden" ||
        normalizedStatus === "gone" ||
        normalizedStatus === "server error" ||
        normalizedStatus === "invalid link" ||
        normalizedStatus === "redirect loop" ||
        normalizedStatus === "interaction error"
    ) {
        return "broken";
    }

    if (
        normalizedStatus == "ssl error" ||
        normalizedStatus == "timeout" ||
        normalizedStatus == "connection error" ||
        normalizedStatus == "dns error" ||
        normalizedStatus == "unknown error" ||
        normalizedStatus == "error"
    ) {
        return "error";
    }

    return "unknown"
}


function getStatusGroup(result) {
    return result.status_group || normalizeStatus(result.status);
}


/**
 * Convert the internal status value into readable text.
 */
function getStatusLabel(status, rawStatus = null) {
    const labels = {
        good: "Valid",
        redirected: "Redirected",
        broken: rawStatus || "Broken",
        error: rawStatus || "Error",
        unknown: "Unknown",
    };

    return labels[status] || labels.unknown;
}


/**
 * Return true when a row requires user review or correction.
 */
function needsAction(result) {
    const statusGroup = getStatusGroup(result);

    return statusGroup === "broken" || statusGroup === "error";
}


/**
 * Prevent raw API values from being inserted as HTML.
 */
function escapeHtml(value) {
    if (value === null || value === undefined) {
        return "";
    }

    return value
        .toString()
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


/**
 * Return true for values that are safe enough to expose as links.
 */
function isClickableUrl(value) {
    if (!value) {
        return false;
    }

    const trimmedValue = value.toString().trim();

    if (!trimmedValue) {
        return false;
    }

    return !/^(javascript|data|vbscript):/i.test(trimmedValue);
}


/**
 * Render plain text with a copy action.
 */
function renderCopyableValue(value, label) {
    if (!value) {
        return "-";
    }

    const escapedValue = escapeHtml(value);

    return `
        <div class="url-content">
            <span>${escapedValue}</span>

            <button
                class="copy-button"
                type="button"
                data-copy="${escapedValue}"
                aria-label="Copy ${escapeHtml(label)}"
            >
                Copy
            </button>
        </div>
    `;
}


function renderInlineActions(value, label) {
    if (!value) {
        return "";
    }

    const escapedValue = escapeHtml(value);
    const openAction = isClickableUrl(value)
        ? `
            <a
                class="icon-action"
                href="${escapedValue}"
                target="_blank"
                rel="noopener noreferrer"
                title="Open ${escapeHtml(label)}"
                aria-label="Open ${escapeHtml(label)}"
            >
                Open
            </a>
        `
        : "";

    return `
        <span class="inline-actions">
            ${openAction}
            <button
                class="icon-action"
                type="button"
                data-copy="${escapedValue}"
                title="Copy ${escapeHtml(label)}"
                aria-label="Copy ${escapeHtml(label)}"
            >
                Copy
            </button>
        </span>
    `;
}


/**
 * Render a URL with open and copy actions.
 */
function renderUrlCell(value, label) {
    if (!value) {
        return "-";
    }

    if (!isClickableUrl(value)) {
        return renderCopyableValue(value, label);
    }

    const escapedValue = escapeHtml(value);

    return `
        <div class="url-content">
            <a
                class="url-link"
                href="${escapedValue}"
                target="_blank"
                rel="noopener noreferrer"
            >
                ${escapedValue}
            </a>

            <button
                class="copy-button"
                type="button"
                data-copy="${escapedValue}"
                aria-label="Copy ${escapeHtml(label)}"
            >
                Copy
            </button>
        </div>
    `;
}


/**
 * Return the fields included in text search.
 */
function getSearchableText(result) {
    return [
        result.status,
        result.http_status,
        result.url,
        result.final_url,
        formatRedirectChain(result.redirect_chain),
        result.response_time_ms,
        result.source_location,
        result.link_type,
        result.source_attribute,
        result.error_message,
    ]
        .filter((value) => value !== null && value !== undefined)
        .join(" ")
        .toLowerCase();
}


/**
 * Return a normalized sort value for a result row.
 */
function getSortValue(result, key) {
    if (key === "status") {
        return getStatusLabel(getStatusGroup(result), result.status)
    }

    return result[key] ?? "";
}


/**
 * Filter, search, and sort result rows for table display and export.
 */
function getVisibleResults(results) {
    const selectedStatus = statusFilter.value;
    const searchTerm = resultsSearchInput.value.trim().toLowerCase();

    const filteredResults = results.filter((result) => {
        const statusGroup = getStatusGroup(result);
        const matchesQuickFilter = (
            quickFilter !== "needs-action" ||
            needsAction(result)
        );

        const matchesStatus = (
            selectedStatus === "all" ||
            statusGroup === selectedStatus
        );

        const matchesSearch = (
            searchTerm === "" ||
            getSearchableText(result).includes(searchTerm)
        );

        return matchesQuickFilter && matchesStatus && matchesSearch;
    });

    if (!currentSort.key) {
        return filteredResults;
    }

    return [...filteredResults].sort((left, right) => {
        const leftValue = getSortValue(left, currentSort.key);
        const rightValue = getSortValue(right, currentSort.key);

        if (
            currentSort.key === "http_status" ||
            currentSort.key === "response_time_ms"
        ) {
            const leftNumber = Number(leftValue);
            const rightNumber = Number(rightValue);

            if (Number.isNaN(leftNumber) && Number.isNaN(rightNumber)) {
                return 0;
            }

            if (Number.isNaN(leftNumber)) {
                return 1;
            }

            if (Number.isNaN(rightNumber)) {
                return -1;
            }

            return currentSort.direction === "asc"
                ? leftNumber - rightNumber
                : rightNumber - leftNumber;
        }

        const comparison = leftValue
            .toString()
            .localeCompare(rightValue.toString(), undefined, {
                numeric: true,
                sensitivity: "base",
            });

        return currentSort.direction === "asc"
            ? comparison
            : -comparison;
    });
}


/**
 * Update visual sort direction labels on sortable headers.
 */
function updateSortButtons() {
    document.querySelectorAll(".sort-button").forEach((button) => {
        const isActive = button.dataset.sortKey === currentSort.key;

        button.dataset.active = isActive ? "true" : "false";
        button.dataset.direction = isActive
            ? currentSort.direction
            : "";
    });
}


/**
 * Escape a value for RFC 4180-style CSV output.
 */
function escapeCsvValue(value) {
    if (value === null || value === undefined) {
        return "";
    }

    const stringValue = value.toString();

    if (/[",\r\n]/.test(stringValue)) {
        return `"${stringValue.replaceAll('"', '""')}"`;
    }

    return stringValue;
}


/**
 * Render the redirect status chain as compact text.
 */
function formatRedirectChain(redirectChain) {
    if (!Array.isArray(redirectChain) || redirectChain.length === 0) {
        return "";
    }

    return redirectChain
        .map((step) => step.status_code ?? "-")
        .join(" -> ");
}


/**
 * Build a portable filename for exported scan results.
 */
function buildCsvFilename() {
    const timestamp = new Date()
        .toISOString()
        .replaceAll(":", "-")
        .replace(/\.\d{3}Z$/, "Z");

    const statusSuffix = statusFilter.value === "all"
        ? "all"
        : statusFilter.value;

    return `link-checker-${statusSuffix}-${timestamp}.csv`;
}


/**
 * Download the currently filtered scan results as CSV.
 */
function exportCurrentResultsToCsv() {
    const filteredResults = getVisibleResults(currentResults);

    if (filteredResults.length === 0) {
        formError.textContent = "There are no rows to export for this filter.";
        formError.classList.remove("hidden");

        return;
    }

    const headers = [
        "source_page",
        "status",
        "status_group",
        "http_status",
        "url",
        "final_url",
        "redirect_chain",
        "response_time_ms",
        "source_location",
        "link_type",
        "source_attribute",
        "error_message",
    ];

    const rows = filteredResults.map((result) => [
        currentSourcePage,
        result.status ?? getStatusLabel(getStatusGroup(result), result.status),
        getStatusGroup(result),
        result.http_status ?? "",
        result.url ?? "",
        result.final_url ?? "",
        formatRedirectChain(result.redirect_chain),
        result.response_time_ms ?? "",
        result.source_location ?? "",
        result.link_type ?? "",
        result.source_attribute ?? "",
        result.error_message ?? "",
    ]);

    const csvContent = [
        headers,
        ...rows,
    ]
        .map((row) => row.map(escapeCsvValue).join(","))
        .join("\r\n");

    const blob = new Blob([csvContent], {
        type: "text/csv;charset=utf-8",
    });

    const downloadUrl = URL.createObjectURL(blob);
    const downloadLink = document.createElement("a");

    downloadLink.href = downloadUrl;
    downloadLink.download = buildCsvFilename();
    downloadLink.click();

    URL.revokeObjectURL(downloadUrl);
}


/**
 * Render the scan summary cards.
 */
function renderSummary(data) {
    currentSourcePage = data.source_page ?? "";

    const summary = data.summary || {};
    const total = summary.total_links ?? data.total_links ?? 0;
    const good = summary.good ?? data.good ?? 0;
    const redirected = summary.redirected ?? data.redirected ?? 0;
    const broken = summary.broken ?? data.broken ?? 0;
    const error = summary.error ?? data.error ?? 0;
    const healthScore = summary.health_score ?? 0;
    const healthState = summary.health_state || "unknown";
    const healthMessage = summary.health_message ||
        "Summary unavailable for this saved scan.";
    const summaryMessage = summary.summary_message ||
        "Summary unavailable for this saved scan.";

    totalLinksElement.textContent = total;
    goodLinksElement.textContent = good;
    redirectedLinksElement.textContent = redirected;
    brokenLinksElement.textContent = broken;
    errorLinksElement.textContent = error;
    healthScoreElement.textContent = `${healthScore}%`;
    healthScoreElement.dataset.health = healthState;
    healthMessageElement.textContent = healthMessage;
    scanSummaryMessageElement.textContent = summaryMessage;

    sourcePageElement.textContent = data.source_page
        ? `Source page: ${data.source_page}`
        : "";

    renderDistributionBar({
        total,
        good,
        redirected,
        broken,
        error,
    });
}


/**
 * Render a proportional status bar so users can read quality at a glance.
 */
function renderDistributionBar(counts) {
    const segments = [
        ["good", counts.good],
        ["redirected", counts.redirected],
        ["broken", counts.broken],
        ["error", counts.error],
    ];

    distributionBar.innerHTML = "";

    if (!counts.total) {
        distributionBar.innerHTML = '<span class="distribution-empty"></span>';

        return;
    }

    segments.forEach(([name, count]) => {
        if (!count) {
            return;
        }

        const segment = document.createElement("span");
        const percent = Math.max((count / counts.total) * 100, 3);

        segment.className = `distribution-segment distribution-${name}`;
        segment.style.width = `${percent}%`;
        segment.title = `${count} ${name}`;

        distributionBar.appendChild(segment);
    });
}


/**
 * Render the most important actionable rows above the full table.
 */
function renderIssues(results) {
    const issueResults = results
        .filter(needsAction)
        .slice(0, 6);

    const totalIssues = results.filter(needsAction).length;

    issuesSubtitleElement.textContent = totalIssues === 0
        ? "No broken links or request errors were detected."
        : `${totalIssues} links require attention.`;

    issuesList.innerHTML = "";

    if (issueResults.length === 0) {
        issuesList.innerHTML = `
            <div class="issue-empty">
                No priority issues in this scan.
            </div>
        `;

        return;
    }

    issueResults.forEach((result) => {
        const statusGroup = getStatusGroup(result);
        const statusLabel = getStatusLabel(statusGroup, result.status);
        const issueItem = document.createElement("article");
        const detail = result.error_description ||
            result.error_message ||
            "No additional details provided.";
        const meta = [
            result.http_status ? `HTTP ${result.http_status}` : null,
            result.link_type,
            result.source_attribute,
        ].filter(Boolean).join(" | ");

        issueItem.className = "issue-item";
        issueItem.innerHTML = `
            <div>
                <span class="status-badge status-${statusGroup}">
                    ${escapeHtml(statusLabel)}
                </span>
            </div>

            <div class="issue-content">
                <strong>${escapeHtml(result.url || "Unknown URL")}</strong>
                <p>${escapeHtml(detail)}</p>
                <dl class="issue-details">
                    <div>
                        <dt>Found at</dt>
                        <dd>${escapeHtml(result.source_location ?? "-")}</dd>
                    </div>
                    <div>
                        <dt>Final URL</dt>
                        <dd>${escapeHtml(result.final_url ?? "-")}</dd>
                    </div>
                </dl>
            </div>

            <div class="issue-meta">
                <span>${escapeHtml(meta || "-")}</span>
                ${renderInlineActions(result.url, "issue URL")}
            </div>
        `;

        issuesList.appendChild(issueItem);
    });
}


/**
 * Render the scan results table.
 */
function renderTable(results) {
    resultsTableBody.innerHTML = "";

    updateSortButtons();

    const filteredResults = getVisibleResults(results);

    if (filteredResults.length === 0) {
        resultsTableBody.innerHTML = `
            <tr>
                <td colspan="7" class="empty-state">
                    No links found for the selected filter.
                </td>
            </tr>
        `;

        return;
    }

    filteredResults.forEach((result) => {
        const statusGroup = getStatusGroup(result);

        const statusLabel = getStatusLabel(statusGroup, result.status);

        const responseTime = result.response_time_ms !== null &&
            result.response_time_ms !== undefined
            ? `${result.response_time_ms} ms`
            : "-";
        const redirectChain = formatRedirectChain(result.redirect_chain);

        const row = document.createElement("tr");

        const details = [
            ["Redirects", redirectChain || "-"],
            ["Type", result.link_type ?? "-"],
            ["Attribute", result.source_attribute ?? "-"],
            ["Error", result.error_message ?? "-"],
        ];

        row.innerHTML = `
            <td>
                <span class="status-badge status-${statusGroup}">
                    ${escapeHtml(statusLabel)}
                </span>
            </td>

            <td>
                ${escapeHtml(result.http_status ?? "-")}
            </td>

            <td class="url-cell">
                ${renderUrlCell(result.url, "link URL")}
            </td>

            <td class="url-cell">
                ${renderUrlCell(result.final_url, "final URL")}
            </td>

            <td>
                ${escapeHtml(redirectChain || "-")}
            </td>

            <td>
                ${escapeHtml(responseTime)}
            </td>

            <td class="location-cell">
                ${escapeHtml(result.source_location ?? "-")}
            </td>

            <td class="details-cell">
                <details>
                    <summary>View</summary>
                    <dl class="row-details">
                        ${details.map(([label, value]) => `
                            <div>
                                <dt>${escapeHtml(label)}</dt>
                                <dd>${escapeHtml(value)}</dd>
                            </div>
                        `).join("")}
                    </dl>
                </details>
            </td>
        `;

        resultsTableBody.appendChild(row);
    });
}


function showScanData(scanData) {
    currentResults = scanData.results ?? [];
    currentSourcePage = scanData.source_page ?? "";

    statusFilter.value = "all";
    resultsSearchInput.value = "";
    currentSort = {
        key: null,
        direction: "asc",
    };
    quickFilter = "all";
    needsActionFilterButton.dataset.active = "false";

    renderSummary(scanData);
    renderIssues(currentResults);
    renderTable(currentResults);

    emptySection.classList.add("hidden");
    resultsSection.classList.remove("hidden");
}


function renderScanTabs() {
    scanTabs.innerHTML = "";
    scanTabs.classList.toggle("hidden", batchScans.length < 2);

    batchScans.forEach((item, index) => {
        const tab = document.createElement("button");
        tab.type = "button";
        tab.className = "scan-tab";
        tab.dataset.index = index;
        tab.dataset.active = index === activeBatchScanIndex ? "true" : "false";
        tab.setAttribute("role", "tab");
        tab.setAttribute("aria-selected", index === activeBatchScanIndex ? "true" : "false");
        tab.textContent = item.error ? `URL ${index + 1} (failed)` : `URL ${index + 1}`;
        scanTabs.appendChild(tab);
    });
}


function showBatchScan(index) {
    activeBatchScanIndex = index;
    const item = batchScans[index];
    renderScanTabs();

    if (item.scan) {
        showScanData(item.scan);
        return;
    }

    showScanData({
        source_page: item.url,
        total_links: 0,
        good: 0,
        redirected: 0,
        broken: 0,
        error: 0,
        results: [],
    });
    formError.textContent = `Could not scan ${item.url}: ${item.error || "Unknown error."}`;
    formError.classList.remove("hidden");
}


function showScanResponse(response) {
    batchScans = Array.isArray(response.scans)
        ? response.scans
        : [{ url: response.source_page, scan: response }];
    activeBatchScanIndex = 0;
    showBatchScan(0);
}


function setHistoryCollapsed(isCollapsed) {
    historyPanel.dataset.collapsed = isCollapsed ? "true" : "false";
    historyList.classList.toggle("hidden", isCollapsed);
    toggleHistoryButton.textContent = isCollapsed ? "Expand" : "Minimize";
    toggleHistoryButton.setAttribute("aria-expanded", isCollapsed ? "false" : "true");
}


function setIssuesCollapsed(isCollapsed) {
    const issuesPanel = issuesList.closest(".issues-panel");

    issuesPanel.dataset.collapsed = isCollapsed ? "true" : "false";
    issuesList.classList.toggle("hidden", isCollapsed);
    toggleIssuesButton.textContent = isCollapsed ? "Expand" : "Minimize";
    toggleIssuesButton.setAttribute("aria-expanded", isCollapsed ? "false" : "true");
}


function renderScanHistory(history) {
    historyList.innerHTML = "";

    if (!Array.isArray(history) || history.length === 0) {
        historySubtitle.textContent = "Recent local scans saved on this machine.";
        historyList.innerHTML = '<div class="history-empty">No saved scans yet.</div>';

        return;
    }

    historySubtitle.textContent = `${history.length} scans saved locally.`;

    history.forEach((item) => {
        const historyItem = document.createElement("button");
        const summary = item.summary || {};
        const issueCount = summary.needs_action_count ??
            (item.broken ?? 0) + (item.error ?? 0);
        const healthScore = summary.health_score;
        const healthLabel = Number.isFinite(Number(healthScore))
            ? `${healthScore}% health`
            : `${item.total_links ?? 0} links`;

        historyItem.className = "history-item";
        historyItem.type = "button";
        historyItem.dataset.scanId = item.id;
        historyItem.dataset.active = item.id === selectedHistoryScanId
            ? "true"
            : "false";
        historyItem.innerHTML = `
            <span>
                <span class="history-url">${escapeHtml(item.source_page ?? "Unknown page")}</span>
                <span class="history-meta">${escapeHtml(formatHistoryDate(item.created_at))}</span>
            </span>

            <span class="history-counts">
                ${escapeHtml(healthLabel)} | ${escapeHtml(issueCount)} issues
            </span>
        `;

        historyList.appendChild(historyItem);
    });
}


async function loadScanHistory() {
    try {
        const response = await fetch("/scans/history");

        if (!response.ok) {
            throw new Error("History could not be loaded.");
        }

        renderScanHistory(await response.json());
    } catch {
        historySubtitle.textContent = "History is unavailable.";
        historyList.innerHTML = '<div class="history-empty">Could not load local scan history.</div>';
    }
}


async function clearScanHistory() {
    if (!window.confirm("Clear all locally saved scan history? This cannot be undone.")) {
        return;
    }

    formError.classList.add("hidden");
    clearHistoryButton.disabled = true;
    clearHistoryButton.textContent = "Clearing...";

    try {
        const response = await fetch("/scans/history", { method: "DELETE" });

        if (!response.ok) {
            throw new Error("History could not be cleared.");
        }

        selectedHistoryScanId = "";
        await loadScanHistory();
        setAppStatus("ready", "Ready");
    } catch (error) {
        formError.textContent = error.message || "History could not be cleared.";
        formError.classList.remove("hidden");
        setAppStatus("error", "Error");
    } finally {
        clearHistoryButton.disabled = false;
        clearHistoryButton.textContent = "Clear history";
    }
}


async function loadHistoryScan(scanId) {
    const response = await fetch(`/scans/history/${encodeURIComponent(scanId)}`);

    if (!response.ok) {
        throw new Error("The selected scan could not be loaded.");
    }

    return response.json();
}


/**
 * Send the page URL to the FastAPI scan endpoint.
 */
async function executeScan(pageUrl, pageUrl2 = "") {
    const scanOptions = getScanOptions();

    const response = await fetch("/scans/jobs", {
        method: "POST",

        headers: {
            "Content-Type": "application/json",
        },

        body: JSON.stringify({
            url: pageUrl,
            ...(pageUrl2 ? { url_2: pageUrl2 } : {}),
            ...scanOptions,
        }),
    });

    if (!response.ok) {
        let errorMessage = "The scan could not be completed.";

        try {
            const errorData = await response.json();

            errorMessage =
                errorData.detail ||
                errorData.message ||
                errorMessage;
        } catch {
            // Keep the default error message when the response is not JSON.
        }

        throw new Error(errorMessage);
    }

    const job = await response.json();

    return new Promise((resolve, reject) => {
        let settled = false;
        const events = new EventSource(
            `/scans/jobs/${encodeURIComponent(job.id)}/events`,
        );

        events.onmessage = (event) => {
            const update = JSON.parse(event.data);
            updateLiveScanProgress(update);

            if (update.status === "completed") {
                settled = true;
                events.close();
                resolve(update.result);
            } else if (update.status === "failed") {
                settled = true;
                events.close();
                reject(new Error(update.error || "The scan could not be completed."));
            }
        };

        events.onerror = () => {
            if (settled) {
                return;
            }

            settled = true;
            events.close();
            reject(new Error("The live scan connection was interrupted."));
        };
    });
}


async function refreshCurrentScanOrHistory() {
    const pageUrl = currentSourcePage || pageUrlInput.value.trim();

    formError.classList.add("hidden");
    refreshHistoryButton.disabled = true;

    if (!pageUrl) {
        refreshHistoryButton.textContent = "Refreshing...";
        setAppStatus("scanning", "Refreshing");

        try {
            await loadScanHistory();
            setAppStatus("ready", "Ready");
        } catch {
            setAppStatus("error", "Error");
        } finally {
            refreshHistoryButton.disabled = false;
            refreshHistoryButton.textContent = "Refresh";
        }

        return;
    }

    startLoadingState(pageUrl, "Refreshing");
    refreshHistoryButton.textContent = "Refreshing...";
    setScanControlsDisabled(true);

    try {
        const scanData = await executeScan(pageUrl);

        selectedHistoryScanId = "";
        showScanResponse(scanData);
        await loadScanHistory();
        setAppStatus("ready", "Ready");
    } catch (error) {
        formError.textContent =
            error.message ||
            "An unexpected error occurred.";

        formError.classList.remove("hidden");
        resultsSection.classList.toggle("hidden", currentResults.length === 0);
        emptySection.classList.toggle("hidden", currentResults.length > 0);
        setAppStatus("error", "Error");
    } finally {
        stopLoadingState();
        refreshHistoryButton.disabled = false;
        refreshHistoryButton.textContent = "Refresh";
        setScanControlsDisabled(false);
        scanButton.textContent = "Analyze";
    }
}


/**
 * Handle form submission without reloading the browser page.
 */
scanForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const pageUrl = pageUrlInput.value.trim();
    const pageUrl2 = pageUrl2Input.value.trim();

    formError.classList.add("hidden");
    startLoadingState(pageUrl, "Scanning");

    setScanControlsDisabled(true);
    scanButton.textContent = "Analyzing...";

    try {
        const scanData = await executeScan(pageUrl, pageUrl2);

        selectedHistoryScanId = "";
        showScanResponse(scanData);
        await loadScanHistory();
        setAppStatus("ready", "Ready");
    } catch (error) {
        formError.textContent =
            error.message ||
            "An unexpected error occurred.";

        formError.classList.remove("hidden");
        emptySection.classList.remove("hidden");
        setAppStatus("error", "Error");
    } finally {
        stopLoadingState();

        setScanControlsDisabled(false);
        scanButton.textContent = "Analyze";
    }
});


scanTabs.addEventListener("click", (event) => {
    const tab = event.target.closest(".scan-tab");
    if (tab) {
        formError.classList.add("hidden");
        showBatchScan(Number(tab.dataset.index));
    }
});


refreshHistoryButton.addEventListener("click", refreshCurrentScanOrHistory);
clearHistoryButton.addEventListener("click", clearScanHistory);


toggleHistoryButton.addEventListener("click", () => {
    setHistoryCollapsed(historyPanel.dataset.collapsed !== "true");
});


toggleIssuesButton.addEventListener("click", () => {
    const issuesPanel = issuesList.closest(".issues-panel");

    setIssuesCollapsed(issuesPanel.dataset.collapsed !== "true");
});


historyList.addEventListener("click", async (event) => {
    const historyItem = event.target.closest(".history-item");

    if (!historyItem) {
        return;
    }

    formError.classList.add("hidden");
    setAppStatus("scanning", "Loading");

    try {
        const scanData = await loadHistoryScan(historyItem.dataset.scanId);

        selectedHistoryScanId = historyItem.dataset.scanId;
        showScanResponse(scanData);
        await loadScanHistory();
        setAppStatus("ready", "Ready");
    } catch (error) {
        formError.textContent = error.message;
        formError.classList.remove("hidden");
        setAppStatus("error", "Error");
    }
});


/**
 * Filter the existing results without executing a new scan.
 */
statusFilter.addEventListener("change", () => {
    quickFilter = "all";
    needsActionFilterButton.dataset.active = "false";
    renderTable(currentResults);
});


/**
 * Search within the current scan results.
 */
resultsSearchInput.addEventListener("input", () => {
    renderTable(currentResults);
});


/**
 * Focus the table on broken links and request errors.
 */
needsActionFilterButton.addEventListener("click", () => {
    quickFilter = quickFilter === "needs-action"
        ? "all"
        : "needs-action";

    statusFilter.value = "all";
    needsActionFilterButton.dataset.active = quickFilter === "needs-action"
        ? "true"
        : "false";
    renderTable(currentResults);
});


/**
 * Sort the table by a selected column.
 */
document.querySelectorAll(".sort-button").forEach((button) => {
    button.addEventListener("click", () => {
        const sortKey = button.dataset.sortKey;

        if (currentSort.key === sortKey) {
            currentSort.direction = currentSort.direction === "asc"
                ? "desc"
                : "asc";
        } else {
            currentSort = {
                key: sortKey,
                direction: "asc",
            };
        }

        renderTable(currentResults);
    });
});


/**
 * Export the visible result set as a CSV file.
 */
exportCsvButton.addEventListener("click", exportCurrentResultsToCsv);


/**
 * Copy result URLs without re-rendering the table.
 */
document.addEventListener("click", async (event) => {
    const copyButton = event.target.closest(".copy-button");

    if (!copyButton) {
        const iconCopyButton = event.target.closest(".icon-action[data-copy]");

        if (!iconCopyButton) {
            return;
        }

        await copyValueFromButton(iconCopyButton);

        return;
    }

    await copyValueFromButton(copyButton);
});


async function copyValueFromButton(copyButton) {
    const valueToCopy = copyButton.dataset.copy;

    if (!valueToCopy) {
        return;
    }

    try {
        await navigator.clipboard.writeText(valueToCopy);

        const originalText = copyButton.textContent;

        copyButton.textContent = "Copied";
        copyButton.disabled = true;

        window.setTimeout(() => {
            copyButton.textContent = originalText;
            copyButton.disabled = false;
        }, 1200);
    } catch {
        formError.textContent = "The URL could not be copied.";
        formError.classList.remove("hidden");
    }
}


loadScanHistory();
